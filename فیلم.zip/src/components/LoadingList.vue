<script setup>
import {VSkeletonLoader} from "vuetify/labs/components";
</script>

<template>
    <v-skeleton-loader class="border mt-3 mx-5" type="heading"></v-skeleton-loader>
</template>

<style scoped></style>